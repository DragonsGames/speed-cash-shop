const Discord = require('discord.js');
const client = new Discord.Client();

client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
});





client.on("message", message => {
  var prefix = "+";

          var args = message.content.substring(prefix.length).split(" ");
          if (message.content.startsWith(prefix + "clear")) {
 if(!message.member.hasPermission('MANAGE_MESSAGES')) return message.reply('? | **ليس لديك الصلاحيه حتى تمسح الشات**');
      var msg;
      msg = parseInt();
    
    message.channel.fetchMessages({limit: msg}).then(messages => message.channel.bulkDelete(messages)).catch(console.error);
    message.channel.sendMessage("", {embed: {
      title: "Done | تم مسح الشات",
      color: 0x06DF00,
      description: "تم المسح„ ",
      footer: {
        text: "آ©speed cash"
      }
    }}).then(msg => {msg.delete(3000)});
                        }

   
});






client.on("message", message => {
 
  if (message.content.startsWith("+bc" )) {
               if (!message.member.hasPermission("ADMINISTRATOR"))  return;
let args = message.content.split(" ").slice(1);
var argresult = args.join(' '); 
message.guild.members.filter(m => m.presence.status !== 'offline').forEach(m => {
m.send(`${argresult}\n ${m}`);
})
message.channel.send(`\`${message.guild.members.filter(m => m.presence.status !== 'online').size}\` : عدد الاعضاء المستلمين`); 
message.delete(); 
};     
});   



client.on('message', message => {
  if (message.content.startsWith("+avatar")) {
      var mentionned = message.mentions.users.first();
  var x5bzm;
    if(mentionned){
        var x5bzm = mentionned;
    } else {
        var x5bzm = message.author;
        
    }
      const embed = new Discord.RichEmbed()
      .setColor("RANDOM")
      .setImage(`${x5bzm.avatarURL}`)
    message.channel.sendEmbed(embed);
  }
});




client.on('message', message => {
  if (message.content === "+roles") {
      if(!message.channel.guild) return;
      var roles = message.guild.roles.map(roles => `${roles.name}, `).join(' ')
      const embed = new Discord.RichEmbed()
      .setColor('RANDOM')
      .addField('Roles:',`**[${roles}]**`)
      message.channel.sendEmbed(embed);
  }
});

client.on('message', message => {
  if (message.content === "+id") {
  let embed = new Discord.RichEmbed()
 .setColor("RANDOM")
 .setThumbnail(message.author.avatarURL)
 .addField("Name:",`${message.author.username}`, true)
 .addField('Discrim:',"#" +  message.author.discriminator, true)
 .addField("ID:", message.author.id, true)
 .addField("Create At:", message.author.createdAt, true)
    
    
 message.channel.sendEmbed(embed);
   }
});


client.on('message', message => {
  var args = message.content.split(/[ ]+/)
  if(message.content.includes('.com')){
    if(!message.member.hasPermission('MANAGE_MESSAGE'))
      message.delete()
  return message.reply(`**Don't Share Links Plz :x:**`)
  }
});


client.on('voiceStateUpdate', (old, now) => {
  const channel = client.channels.get('517471539340378133');
  const currentSize = channel.guild.members.filter(m => m.voiceChannel).size;
  const size = channel.name.match(/\[\s(\d+)\s\]/);
  if (!size) return channel.setName(`Voice Online: [ ${currentSize} ]`);
  if (currentSize !== size) channel.setName(`Voice Online: [ ${currentSize} ]`);
});



client.on('message', function(message) {
  if (message.channel.type === "dm") {
      if (message.author.id === client.user.id) return;
      var iiMo = new Discord.RichEmbed()
      .setColor('RANDOM')
      .setTimestamp()
      .setTitle('``I have received a new DM !``')
      .setThumbnail(`${message.author.avatarURL}`)
      .setDescription(`\n\n\`\`\`${message.content}\`\`\``)
      .setFooter(`From **${message.author.tag} (${message.author.id})**`)
  client.channels.get("517473315787636741").send({embed:iiMo});
  }
});


  


client.on('message', message => {
  var prefix = "+";
  if (message.author.bot) return;
  if (!message.content.startsWith(prefix)) return;

  let command = message.content.split(" ")[0];
  command = command.slice(prefix.length);


let args = message.content.split(" ").slice(1);
let x = args.join(" ")
  if(message.content.startsWith(prefix + 'say')) {
      message.channel.send(''+x);
          message.delete(999)
  }
  
 
});











client.login('NTE3NDQ2Mzk3NjM3Njg5MzQ0.DuCWAg.rpsKMQPyJfzBW1l9hsJvv30oPmM');